package com.cognizant.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import java.sql.Date;
import java.util.List;

@Entity
public class Cash {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderId;
	@Column(name="user_id")
	private int userid;
	private String deliveryAddress;
	//@Temporal (TemporalType.DATE)
	private Date orderDate;
	private String paymentMode;
	private int orderAmount;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "order_item_id")
	private List<OrderItem> orderItems; 
	
	public Cash() {
		// TODO Auto-generated constructor stub
	}

	public Cash(int orderId, int userid, String deliveryAddress, Date orderDate, String paymentMode, int orderAmount,
			List<OrderItem> orderItems) {
		super();
		this.orderId = orderId;
		this.userid = userid;
		this.deliveryAddress = deliveryAddress;
		this.orderDate = orderDate;
		this.paymentMode = paymentMode;
		this.orderAmount = orderAmount;
		this.orderItems = orderItems;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public int getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(int orderAmount) {
		this.orderAmount = orderAmount;
	}

	public List<OrderItem> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", userid=" + userid + ", deliveryAddress=" + deliveryAddress
				+ ", orderDate=" + orderDate + ", paymentMode=" + paymentMode + ", orderAmount=" + orderAmount
				+ ", orderItems=" + orderItems + "]";
	}

	
}
