package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class OrderItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int productid;
	private String productName;
	private int productPrice;
	private int quantity;
	private int subTotal;
	private int orderId;
	
	public OrderItem() {
		// TODO Auto-generated constructor stub
	}
	
	

	public OrderItem(int id, int productid, String productName, int productPrice, int quantity, int subTotal,
			int orderId) {
		super();
		this.id = id;
		this.productid = productid;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
		this.subTotal = subTotal;
		this.orderId = orderId;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(int subTotal) {
		this.subTotal = subTotal;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	@Override
	public String toString() {
		return "OrderItem [id=" + id + ", productid=" + productid + ", productName=" + productName + ", productPrice="
				+ productPrice + ", quantity=" + quantity + ", subTotal=" + subTotal + ", orderId=" + orderId + "]";
	}

	
}
