package com.cts.ecartclient.controllers;

import com.cts.ecartclient.model.ApplicationUser;
import com.cts.ecartclient.model.Cart;
import com.cts.ecartclient.model.Order;
import com.cts.ecartclient.model.OrderItem;
import com.cts.ecartclient.model.Product;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.function.ServerRequest.Headers;

@Controller
public class ClientController {
    @GetMapping("/")
    public String showHome(){
        return "index";
    }
    @RequestMapping("/loginUser")
	public String login(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_LOGIN");
		return "index";
	}
    @PostMapping("/login")
    public String processForm(@RequestParam("username") String userName,@RequestParam("password") String password,HttpServletRequest request,HttpSession session){
        RestTemplate rt=new RestTemplate();
        ApplicationUser user=new ApplicationUser();
//        Product product=new Product();
        user.setUserName(userName);
        user.setPassword(password);
    	ApplicationUser[] users=rt.getForObject("http://ltin280843.cts.com:8090/api/auth/allUsers", ApplicationUser[].class);
    	
        ResponseEntity<String> response=rt.postForEntity("http://ltin280843.cts.com:8090/api/auth/login",user,String.class);
        
        List<ApplicationUser> userList=new ArrayList<ApplicationUser>();
        Arrays.stream(users).forEach(userData->{
        	userList.add(new ApplicationUser(userData.getUserId(),userData.getUserName(),userData.getPassword()));
    	});
        
        
        if(response.getStatusCode().value()==200){
        	session.setAttribute("userName", userName);
        	ApplicationUser userDetail=null;
            
            for(ApplicationUser u:userList) {
            	if(u.getUserName().equalsIgnoreCase(userName)) {
            		userDetail=u;
            		
            	}
            }
            session.setAttribute("userid",userDetail.getUserId());
        	
            return "products";
        }
        else if(response.getStatusCode().value()>200) {
			
			request.setAttribute("mode", "MODE_LOGIN");
			return "index";
			
		}
        return "index";
        

    }
    
    @GetMapping("/home")
    public String home() {
    	return "products";
    }
    
    @GetMapping("/productList")
    public String productList(ModelMap model,HttpServletRequest request) {
    	RestTemplate rt=new RestTemplate();
        Product[] products=rt.getForObject("http://ltin280843.cts.com:8084/allProducts", Product[].class);
        List<Product> productList=new ArrayList<Product>();
        Arrays.stream(products).forEach(product->{
    		productList.add(new Product(product.getProductId(),product.getProductName(),
    				product.getProductPrice(),product.getProductDescription(),product.getProductImageUrl()));
    	});
    	
    	model.addAttribute("msg", productList);
//    	System.out.println(productList);
//    	for(Product p:productList){
//    		System.out.println(p.getProductName());
//    	}
    	
    	request.setAttribute("mode", "PRODUCT-LIST");
    	
    	return "products";
    	
    	
    }
    
    @GetMapping("/userLogout")
	public String userLogOut(HttpSession session)
	{
		session.invalidate();
		
		return "redirect:/";
	}
    
    @RequestMapping("/add-product")
    public String addCart(@RequestParam int productId,HttpServletRequest request,HttpSession session) {
    	RestTemplate rt=new RestTemplate();
    	
        
    	Product[] products=rt.getForObject("http://ltin280843.cts.com:8084/allProducts", Product[].class);
        
    	ApplicationUser[] users=rt.getForObject("http://ltin280843.cts.com:8090/api/auth/allUsers", ApplicationUser[].class);

    	List<Product> productList=new ArrayList<Product>();
        Arrays.stream(products).forEach(product->{
    		productList.add(new Product(product.getProductId(),product.getProductName(),
    				product.getProductPrice(),product.getProductDescription(),product.getProductImageUrl()));
    	});
        List<ApplicationUser> userList=new ArrayList<ApplicationUser>();
        Arrays.stream(users).forEach(user->{
        	userList.add(new ApplicationUser(user.getUserId(),user.getUserName(),user.getPassword()));
    	});
        
        System.out.println(userList);
        
        Product productData=null;
        for(Product p:productList) {
        	if(p.getProductId()==productId) {
        		productData=p;
        	}
        }
        
        String userName=(String) session.getAttribute("userName");
        System.out.println(userName);
        ApplicationUser userData=null;
        
        for(ApplicationUser u:userList) {
        	if(u.getUserName().equalsIgnoreCase(userName)) {
        		userData=u;
        		
        		
        	}
        }
      
        
        Cart cart=new Cart();
        cart.setProductId(productData.getProductId());
        cart.setProductName(productData.getProductName());
        cart.setProductPrice(productData.getProductPrice());
        
        System.out.println(userData.getUserId());
        
        cart.setUserId(userData.getUserId());
        session.setAttribute("userId", userData.getUserId());
        
    	Cart cartData=rt.postForObject("http://ltin280843.cts.com:8086/addCart", cart ,Cart.class);
    	
        request.setAttribute("mode", "PRODUCT-ADD");
    	return "products";
    }
    
    
    @GetMapping("/cartList")
    public String cartList(ModelMap model,HttpServletRequest request,HttpSession session) {
    	
    	RestTemplate rt=new RestTemplate();
    	int userId=(int) session.getAttribute("userid");
        Cart[] carts=rt.getForObject("http://ltin280843.cts.com:8086/allCartItems/"+userId, Cart[].class);
        List<Cart> cartList=new ArrayList<Cart>();
        Arrays.stream(carts).forEach(cart->{
        	cartList.add(new Cart(cart.getId(),cart.getUserId(),cart.getProductId(),cart.getProductName(),
        			cart.getProductPrice(),cart.getQuantity(),cart.getSubTotal()));
    	});
    	
    	model.addAttribute("msg", cartList);
    	session.setAttribute("cartItems", cartList);
    	System.out.println(cartList);
    	request.setAttribute("mode", "CART-LIST");
    	
    	return "products";
    	
    	
    }
    
    @RequestMapping("/delete-product")
   public String deleteCartItem(@RequestParam("productId") int productId,HttpSession session,ModelMap model,HttpServletRequest request) {
    	
    	RestTemplate rt=new RestTemplate();
    	int userId=(int) session.getAttribute("userid");
    	rt.delete("http://ltin280843.cts.com:8086/cartDelete/"+productId+"/"+userId);
    	Cart[] carts=rt.getForObject("http://ltin280843.cts.com:8086/allCartItems/"+userId, Cart[].class);
        List<Cart> cartList=new ArrayList<Cart>();
        Arrays.stream(carts).forEach(cart->{
        	cartList.add(new Cart(cart.getId(),cart.getUserId(),cart.getProductId(),cart.getProductName(),
        			cart.getProductPrice(),cart.getQuantity(),cart.getSubTotal()));
    	});
        
        model.addAttribute("msg", cartList);

    	System.out.println(cartList);
    	request.setAttribute("mode", "CART-LIST");
    	
    	return "products";
        
    }
    
    @GetMapping("/placeOrder")
	public String placeOrder(HttpSession session) {
		List<Cart> cartList=(List<Cart>) session.getAttribute("cartItems");
		List<OrderItem> items=new ArrayList();
		int grandTotal=0;
		for(Cart c:cartList) {
			OrderItem o=new OrderItem();
			o.setOrderId(0);
			o.setProductid(c.getProductId());
			o.setProductName(c.getProductName());
			o.setProductPrice(c.getProductPrice());
			o.setQuantity(c.getQuantity());
			o.setSubTotal(c.getSubTotal());
			grandTotal+=c.getSubTotal();
			items.add(o);
		
		}
		session.setAttribute("orderItems",items);
		session.setAttribute("grandTotal",grandTotal);
		
		return "PlaceOrder";
	}
	
	@PostMapping("/confirmOrder")
	public String confirmOrder(@RequestParam("address") String address,@RequestParam("mode") String mode, HttpSession session) {
		
		long millis=System.currentTimeMillis();
		int userId=(int) session.getAttribute("userid");
        java.sql.Date date=new java.sql.Date(millis);  
        if(session.getAttribute("userid")==null) {
        	return "SessionExpired";
        }
        RestTemplate rt=new RestTemplate();
		Order order=new Order();
		order.setDeliveryAddress(address);
		order.setPaymentMode(mode);
		order.setOrderAmount((int) session.getAttribute("grandTotal"));
		order.setUserid((int) session.getAttribute("userid"));
		order.setOrderItems((List<OrderItem>) session.getAttribute("orderItems"));
		order.setOrderDate(date);
		System.out.println("order"+order);
		System.out.println("ordered Items"+order.getOrderItems());
		ResponseEntity<Object> res=rt.postForEntity("http://ltin280843.cts.com:8085/placeOrder", order, Object.class);
		System.out.println(res.getStatusCodeValue());
		rt.delete("http://ltin280843.cts.com:8086/cartDelete/"+userId);
		
		
		List<Cart> cartList=null;
		session.setAttribute("cartItems", cartList);
		
		return "Thanks";
	}
	
    
    
    
}
