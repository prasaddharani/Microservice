package com.cts.authenticationservice;

import com.cts.authenticationservice.entities.ApplicationUser;
import com.cts.authenticationservice.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapSeed implements CommandLineRunner {
    private UserRepository repository;

    public BootStrapSeed(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) throws Exception {
        ApplicationUser user1=new ApplicationUser();
        user1.setUserName("prasad");
        user1.setPassword("prasad@123");
        ApplicationUser user2=new ApplicationUser();
        user2.setUserName("dharani");
        user2.setPassword("dharani@123");
        repository.save(user1);
        repository.save(user2);

    }
}

