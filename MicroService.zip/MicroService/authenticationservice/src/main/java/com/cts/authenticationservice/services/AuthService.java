package com.cts.authenticationservice.services;

import java.util.ArrayList;
import java.util.List;


import com.cts.authenticationservice.entities.ApplicationUser;

public interface AuthService {
    boolean validate(String userName,String password);
    
    public List<ApplicationUser> getUsers();
}
