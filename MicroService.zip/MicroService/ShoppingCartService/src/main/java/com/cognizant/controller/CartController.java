package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Cart;
import com.cognizant.repository.CartRepository;
import com.cognizant.service.CartService;

@RestController
@EnableEurekaClient
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private CartRepository cartRepository;
	
	@RequestMapping(value="/allCartItems/{userId}",method = RequestMethod.GET)
	public List<Cart> getCartItems(@PathVariable("userId") int userId){
		
		return cartService.getCartItems(userId);
		
	}
	
	@PostMapping(value="/addCart",consumes= MediaType.APPLICATION_JSON_VALUE,produces= MediaType.APPLICATION_JSON_VALUE)
	public void addCart(@RequestBody Cart cart) {
		
		int userId=cart.getUserId();
		int productId=cart.getProductId();
		String productName=cart.getProductName();
		int prodoctPrice=cart.getProductPrice();
		
		
		
		Cart cartExist=cartRepository.findCartExistByUserId(userId,productId);
		if(cartExist!=null) {
			cart.setId(cartExist.getId());
			cart.setProductId(productId);
			cart.setProductName(productName);
			cart.setQuantity(cartExist.getQuantity()+1);
			cart.setProductPrice(prodoctPrice);
			cart.setSubTotal(prodoctPrice*cart.getQuantity());
			cart.setUserId(userId);
			
			cartService.addCartItem(cart);
			System.out.println("if loop"+cart);
			
		}
		else {
		cart.setQuantity(1);
		cart.setSubTotal(prodoctPrice);
		cartService.addCartItem(cart);
		
		}
		 
	}
	
	
	
	
	@RequestMapping(value="/cartDelete/{productId}/{userId}",method=RequestMethod.DELETE,produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public void deleteCart(@PathVariable("productId") int productId,@PathVariable int userId)
	{
		
		Cart cart=cartRepository.findByProductId(productId);
		Cart cartExist=cartRepository.findCartExistByUserId(cart.getUserId(),cart.getProductId());
		if(cartExist.getQuantity()>1) {
			cart.setId(cartExist.getId());
			cart.setProductId(cartExist.getProductId());
			cart.setProductName(cartExist.getProductName());
			cart.setQuantity(cartExist.getQuantity()-1);
			cart.setProductPrice(cartExist.getProductPrice());
			cart.setSubTotal(cartExist.getProductPrice()*cart.getQuantity());
			cart.setUserId(cartExist.getUserId());
			
			cartService.addCartItem(cart);
			System.out.println("if loop"+cart);
			
		}
		else {
		
		cartRepository.deleteCart(userId,productId);
		
		}
		 
	}
	
	@RequestMapping(value="/cartDelete/{userId}",method=RequestMethod.DELETE,produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public void deleteCartByUserId(@PathVariable int userId)
	{
		cartRepository.deleteByUserId(userId);
	}

}
