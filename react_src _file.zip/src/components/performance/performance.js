import React from 'react';
const performance = props => {
    return (
        <div>
            <table className="table">
                <tr>
                    <td>{props.performance.date}</td>
                    <td><center>{props.performance.name}</center></td>
                    <td><center>{props.performance.price}</center></td>
                </tr>
            </table>
        </div>
    )
}
export default performance;