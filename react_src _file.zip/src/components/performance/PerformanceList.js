import React from 'react';
import Performance from './performance';
const performanceList = props => {
    let performances = props.performances.map(performance => {
        return <Performance  key={performance.id} performance={performance} />
    })
    return (
        <div>
            <table className="table" align="center" border="1">
            <tr>
                    <th>Date</th>
                    <th>Company</th>
                    <th>Price</th>
            </tr>
            </table>
            {performances}
        </div>
    )
}
export default performanceList;
