import React from 'react';
import Performance from './performance';
import PerformanceList from './PerformanceList.js';
import $ from 'jquery';
import Popper from 'popper.js';




class PerformanceComponent extends React.Component {
    constructor() {
      super();
      this.state = {
        fields: {},
        errors: {},
        isSubmitted:false,
        isctswipro:false,
        isctstcs:false,
        istcswipro:false,
        ctsList:[
             {id:1, name:'CTS', description: 'Cognizant Technology Solution', price: '1500$' , date:'2020-04-18'},
            {id:1, name:'CTS', description: 'Cognizant Technology Solution', price: '2000$' , date:'2020-04-19'}
        ],
        tcsList:[
            {id:2, name:'TCS', description: 'Tata Consultancy Service', price: '1400$' , date:'2020-04-18'},
            {id:2, name:'TCS', description: 'Tata Consultancy Service', price: '1000$' , date:'2020-04-19'}
        ],
        wiproList:[
            {id:3, name:'Wipro', description: 'Wipro Private Limited', price: '1000$',date:'2020-04-18' },
            {id:3, name:'Wipro', description: 'Wipro Private Limited', price: '1500$',date:'2020-04-19' }
        ],
        wiproctsList:[],
          
        wiprotcsList:[],

        tcsctsList:[]

      }

     
      this.handleChange = this.handleChange.bind(this);
      this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);
      
      console.log("Before isSubmit value "+this.state.isSubmitted);


    };

    handleChange(e) {
      let fields = this.state.fields;
      fields[e.target.name] = e.target.value;
      this.setState({
        fields
      });

    }

    submituserRegistrationForm(e) {
        e.preventDefault();
      if (this.validateForm()) {
          let fields = {};
          fields["company1"] = "";
          fields["company2"] = "";
          fields["fromDate"] = "";
          fields["toDate"] = "";
          if((this.state.fields["company1"]==="CTS" || this.state.fields["company1"]==="WIPRO" ) && (this.state.fields["company2"]==="CTS" || this.state.fields["company2"]==="WIPRO")){
                this.setState({
                    wiproctsList: this.state.wiproList.concat(this.state.ctsList),
                    isctswipro:true,
                    isctstcs:false,
                    istcswipro:false

                });
          }
          if((this.state.fields["company1"]==="CTS" || this.state.fields["company1"]==="TCS") && (this.state.fields["company2"]==="TCS" || this.state.fields["company2"]==="CTS")){
            this.setState({
                tcsctsList:this.state.tcsList.concat(this.state.ctsList),
                isctstcs:true,
                isctswipro:false,
                istcswipro:false
            });
        }
        if((this.state.fields["company1"]==="TCS" || this.state.fields["company1"]==="WIPRO") && (this.state.fields["company2"]==="TCS" || this.state.fields["company2"]==="WIPRO")){
            this.setState({
                wiprotcsList:this.state.wiproList.concat(this.state.tcsList),
                isctstcs:false,
                istcswipro:true,
                isctswipro:false

            });
        }

          this.setState({fields:fields});
          this.setState({
            isSubmitted: true
          });
         console.log("After Submitting"+this.state.isSubmitted);
        
          
      }

      

    }

    
    

    validateForm() {

      let fields = this.state.fields;
      let errors = {};
      let formIsValid = true;

      if (!fields["company1"]) {
        formIsValid = false;
        errors["company1"] = "*Please choose company1.";
      }

      

      if (!fields["company2"]) {
        formIsValid = false;
        errors["company2"] = "*Please choose company2.";
      }


      if (!fields["fromDate"]) {
        formIsValid = false;
        errors["fromDate"] = "*Please enter fromDate.";
      }

      

      if (!fields["toDate"]) {
        formIsValid = false;
        errors["toDate"] = "*Please enter toDate.";
      }

      
      
      this.setState({
        errors: errors
      });
      return formIsValid;


    }

   
    

  render() {
    return (

    <div id="main-registration-container">
     <div id="register">
        <h3>Compare Pottential Companies</h3>
        <h4>Make smart investment decision</h4>
        <form method="post"  name="userRegistrationForm"  onSubmit={this.submituserRegistrationForm}>
        <div class="form-row">
        <div class="form-group col-md-6">
        <label>Company1 :</label>
        <select  class="form-control" id="company1" name="company1" onChange={this.handleChange}>
            <option>Choose Company1</option>
            <option value="CTS">CTS</option>
            <option value="WIPRO">WIPRO</option>
            <option value="TCS">TCS</option>
        </select>
        <div className="errorMsg" className="text-danger">{this.state.errors.company1}</div>
        </div>
        <div class="form-group col-md-6">
        <label>Company2 :</label>
        <select  class="form-control" id="company2" name="company2" onChange={this.handleChange}>
            <option>Choose Company2</option>
            <option value="CTS">CTS</option>
            <option value="WIPRO">WIPRO</option>
            <option value="TCS">TCS</option>
        </select>
        <div className="errorMsg" className="text-danger">{this.state.errors.company2}</div>
        </div>
        </div>
        <div class="form-row">
        <div class="form-group col-md-6">
        <label>From Date:</label>
        <input type="Date" class="form-control" name="fromDate" value={this.state.fields.fromDate} onChange={this.handleChange}   />
        <div className="errorMsg" className="text-danger">{this.state.errors.fromDate}</div>
        </div>
        <div class="form-group col-md-6">
        <label>To Date:</label>
        <input type="Date" class="form-control" name="toDate" value={this.state.fields.toDate} onChange={this.handleChange} />
        <div className="errorMsg" className="text-danger">{this.state.errors.toDate}</div>
        </div>
        </div>
        <input type="submit" className="btn btn-primary" className="button"  value="Fetch Details" />
        </form>
        </div>
        
        { this.state.isctswipro ?  <div>
        <PerformanceList performances={this.state.wiproctsList} /> 
        </div> : null}
        { this.state.isctstcs ?  <div>
        <PerformanceList performances={this.state.tcsctsList} /> 
        </div> : null}
        { this.state.istcswipro ?  <div>
        <PerformanceList performances={this.state.wiprotcsList} /> 
        </div> : null}


        
</div>
    

      );
  }


}


export default PerformanceComponent;