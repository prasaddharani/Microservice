import React from 'react';
const menuComponent = props => {
    return (
        <nav className="navbar navbar-expand-md navbar-dark bg-primary mb-5">
            <a className="navbar-brand" href="#">mStockApp</a>
            <button className="navbar-toggler" data-toggle="collapse"
                data-target="#navcontent">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navcontent">
                <ul className="navbar-nav">
                    <li className="nav-item">
                        <a className="nav-link" onClick={() => props.click('companies')} href="#">Companies</a>
                    </li>
                    {props.isLoggedIn ? <li className="nav-item">
                        <a className="nav-link" onClick={() => props.click("watchlist")} href="#">WatchList</a>
                    </li> : null}
                    {props.isLoggedIn ? <li className="nav-item">
                        <a className="nav-link" onClick={() => props.click("performance")}>Compare Performance</a>
                    </li> : null}
                    {!props.isLoggedIn ? <li className="nav-item">
                        <a className="nav-link" onClick={() => props.click('login')} href="#">Login</a>
                    </li> : null}
                    {props.isLoggedIn ? <li className="nav-item">
                        <a className="nav-link" onClick={props.logout} href="#">Logout</a>
                    </li> : null}
                </ul>
            </div>
        </nav>
    )
}
export default menuComponent;