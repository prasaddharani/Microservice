import React from 'react';
import Company from './company/Company';
const companyList = props => {
    let companies = props.companies.map(company => {
        return <Company addToWatch={props.add} key={company.id} company={company} />
    })
    return (
        <div className="d-flex justify-content-between">
            {companies}
        </div>
    )
}
export default companyList;
