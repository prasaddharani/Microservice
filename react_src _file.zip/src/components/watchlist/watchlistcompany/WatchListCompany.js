import React from 'react';
const watchListCompany = props => {
    return (
        <div className="card">
            <h2 className="card-header">
               <center>{props.company.name}</center> 
            </h2>
            <p className="card-body">
                {props.company.description}
            </p>
            <h3 className="card-title"><center>{props.company.price}</center></h3>
            <button type="button" onClick={props.removeCompany} className="btn btn-danger">Remove</button>
        </div>
    )
}
export default watchListCompany;