import React from 'react';
import WatchListCompany from './watchlistcompany/WatchListCompany';
const watchList = props => {
    let watchList = null;
    if (props.companies.length != 0) {
        watchList = props.companies.map((company, index) => {
            return <WatchListCompany removeCompany={() => props.remove(index)} company={company} />
        });
    }
    return (
        <div className="d-flex justify-content-between">
            {watchList}
        </div>
    )
}
export default watchList;